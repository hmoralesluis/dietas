<?php

use Symfony\Component\Routing\Exception\MethodNotAllowedException;
use Symfony\Component\Routing\Exception\ResourceNotFoundException;
use Symfony\Component\Routing\RequestContext;

/**
 * appProdUrlMatcher.
 *
 * This class has been auto-generated
 * by the Symfony Routing Component.
 */
class appProdUrlMatcher extends Symfony\Bundle\FrameworkBundle\Routing\RedirectableUrlMatcher
{
    /**
     * Constructor.
     */
    public function __construct(RequestContext $context)
    {
        $this->context = $context;
    }

    public function match($pathinfo)
    {
        $allow = array();
        $pathinfo = rawurldecode($pathinfo);
        $context = $this->context;
        $request = $this->request;

        // about
        if ($pathinfo === '/about') {
            return array (  '_controller' => 'App\\FrontBundle\\Controller\\AboutController::aboutAction',  '_route' => 'about',);
        }

        // contact
        if ($pathinfo === '/contact') {
            return array (  '_controller' => 'App\\FrontBundle\\Controller\\ContactController::contactAction',  '_route' => 'contact',);
        }

        // homepage
        if ($pathinfo === '/homepage') {
            return array (  '_controller' => 'App\\FrontBundle\\Controller\\HomepageController::homepageAction',  '_route' => 'homepage',);
        }

        // join
        if ($pathinfo === '/join') {
            return array (  '_controller' => 'App\\FrontBundle\\Controller\\JoinController::JoinAction',  '_route' => 'join',);
        }

        // login
        if ($pathinfo === '/login') {
            return array (  '_controller' => 'App\\FrontBundle\\Controller\\LoginController::loginAction',  '_route' => 'login',);
        }

        // check_path
        if ($pathinfo === '/check') {
            return array (  '_controller' => 'App\\FrontBundle\\Controller\\LoginController::loginCheckAction',  '_route' => 'check_path',);
        }

        if (0 === strpos($pathinfo, '/product')) {
            // product
            if (preg_match('#^/product(?:/(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'product')), array (  'id' => NULL,  '_controller' => 'App\\FrontBundle\\Controller\\ProductController::productAction',));
            }

            // products
            if (0 === strpos($pathinfo, '/products/type') && preg_match('#^/products/type(?:/(?P<name>[^/]++))?$#s', $pathinfo, $matches)) {
                return $this->mergeDefaults(array_replace($matches, array('_route' => 'products')), array (  'name' => NULL,  '_controller' => 'App\\FrontBundle\\Controller\\ProductController::productsAction',));
            }

        }

        if (0 === strpos($pathinfo, '/backoffice')) {
            // backoffice
            if ($pathinfo === '/backoffice') {
                return array (  '_controller' => 'App\\AdminBundle\\Controller\\HomeController::indexAction',  '_route' => 'backoffice',);
            }

            if (0 === strpos($pathinfo, '/backoffice/config')) {
                if (0 === strpos($pathinfo, '/backoffice/config/option')) {
                    // asociate_options_to_role
                    if ($pathinfo === '/backoffice/config/option/asociate/options') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_asociate_options_to_role;
                        }

                        return array (  '_controller' => 'App\\AdminBundle\\Controller\\OptionController::asociateOptionsToRole',  '_route' => 'asociate_options_to_role',);
                    }
                    not_asociate_options_to_role:

                    // backoffice_config_option
                    if (0 === strpos($pathinfo, '/backoffice/config/option/list') && preg_match('#^/backoffice/config/option/list(?:/(?P<id>[^/]++))?$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_backoffice_config_option;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_option')), array (  'id' => NULL,  '_controller' => 'App\\AdminBundle\\Controller\\OptionController::indexAction',));
                    }
                    not_backoffice_config_option:

                    // backoffice_config_option_create
                    if ($pathinfo === '/backoffice/config/option/') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_backoffice_config_option_create;
                        }

                        return array (  '_controller' => 'App\\AdminBundle\\Controller\\OptionController::createAction',  '_route' => 'backoffice_config_option_create',);
                    }
                    not_backoffice_config_option_create:

                    // backoffice_config_option_new
                    if ($pathinfo === '/backoffice/config/option/new') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_backoffice_config_option_new;
                        }

                        return array (  '_controller' => 'App\\AdminBundle\\Controller\\OptionController::newAction',  '_route' => 'backoffice_config_option_new',);
                    }
                    not_backoffice_config_option_new:

                    // backoffice_config_option_show
                    if (preg_match('#^/backoffice/config/option/(?P<id>[^/]++)/show$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_backoffice_config_option_show;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_option_show')), array (  '_controller' => 'App\\AdminBundle\\Controller\\OptionController::showAction',));
                    }
                    not_backoffice_config_option_show:

                    // backoffice_config_option_edit
                    if (preg_match('#^/backoffice/config/option/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_backoffice_config_option_edit;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_option_edit')), array (  '_controller' => 'App\\AdminBundle\\Controller\\OptionController::editAction',));
                    }
                    not_backoffice_config_option_edit:

                    // backoffice_config_option_update
                    if (preg_match('#^/backoffice/config/option/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'PUT') {
                            $allow[] = 'PUT';
                            goto not_backoffice_config_option_update;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_option_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\OptionController::updateAction',));
                    }
                    not_backoffice_config_option_update:

                    // backoffice_config_option_delete
                    if (preg_match('#^/backoffice/config/option/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'DELETE') {
                            $allow[] = 'DELETE';
                            goto not_backoffice_config_option_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_option_delete')), array (  '_controller' => 'App\\AdminBundle\\Controller\\OptionController::deleteAction',));
                    }
                    not_backoffice_config_option_delete:

                }

                if (0 === strpos($pathinfo, '/backoffice/config/role')) {
                    // backoffice_config_role
                    if (rtrim($pathinfo, '/') === '/backoffice/config/role') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_backoffice_config_role;
                        }

                        if (substr($pathinfo, -1) !== '/') {
                            return $this->redirect($pathinfo.'/', 'backoffice_config_role');
                        }

                        return array (  '_controller' => 'App\\AdminBundle\\Controller\\RoleController::indexAction',  '_route' => 'backoffice_config_role',);
                    }
                    not_backoffice_config_role:

                    // backoffice_config_role_create
                    if ($pathinfo === '/backoffice/config/role/') {
                        if ($this->context->getMethod() != 'POST') {
                            $allow[] = 'POST';
                            goto not_backoffice_config_role_create;
                        }

                        return array (  '_controller' => 'App\\AdminBundle\\Controller\\RoleController::createAction',  '_route' => 'backoffice_config_role_create',);
                    }
                    not_backoffice_config_role_create:

                    // backoffice_config_role_new
                    if ($pathinfo === '/backoffice/config/role/new') {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_backoffice_config_role_new;
                        }

                        return array (  '_controller' => 'App\\AdminBundle\\Controller\\RoleController::newAction',  '_route' => 'backoffice_config_role_new',);
                    }
                    not_backoffice_config_role_new:

                    // backoffice_config_role_show
                    if (preg_match('#^/backoffice/config/role/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_backoffice_config_role_show;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_role_show')), array (  '_controller' => 'App\\AdminBundle\\Controller\\RoleController::showAction',));
                    }
                    not_backoffice_config_role_show:

                    // backoffice_config_role_edit
                    if (preg_match('#^/backoffice/config/role/(?P<id>[^/]++)/edit$#s', $pathinfo, $matches)) {
                        if (!in_array($this->context->getMethod(), array('GET', 'HEAD'))) {
                            $allow = array_merge($allow, array('GET', 'HEAD'));
                            goto not_backoffice_config_role_edit;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_role_edit')), array (  '_controller' => 'App\\AdminBundle\\Controller\\RoleController::editAction',));
                    }
                    not_backoffice_config_role_edit:

                    // backoffice_config_role_update
                    if (preg_match('#^/backoffice/config/role/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'PUT') {
                            $allow[] = 'PUT';
                            goto not_backoffice_config_role_update;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_role_update')), array (  '_controller' => 'App\\AdminBundle\\Controller\\RoleController::updateAction',));
                    }
                    not_backoffice_config_role_update:

                    // backoffice_config_role_delete
                    if (preg_match('#^/backoffice/config/role/(?P<id>[^/]++)$#s', $pathinfo, $matches)) {
                        if ($this->context->getMethod() != 'DELETE') {
                            $allow[] = 'DELETE';
                            goto not_backoffice_config_role_delete;
                        }

                        return $this->mergeDefaults(array_replace($matches, array('_route' => 'backoffice_config_role_delete')), array (  '_controller' => 'App\\AdminBundle\\Controller\\RoleController::deleteAction',));
                    }
                    not_backoffice_config_role_delete:

                }

            }

        }

        // logout
        if ($pathinfo === '/logout') {
            return array('_route' => 'logout');
        }

        throw 0 < count($allow) ? new MethodNotAllowedException(array_unique($allow)) : new ResourceNotFoundException();
    }
}
