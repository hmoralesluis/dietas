<?php

namespace App\AdminBundle\Form;

use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolverInterface;

class OptionType extends AbstractType
{
    /**
     * @param FormBuilderInterface $builder
     * @param array $options
     */
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
            ->add('name', 'text', array('label' => 'Name'))
            ->add('path', 'text', array('label' => 'Path', 'attr' => array('class' => 'not-required')))
            ->add('icon', 'text', array('label' => 'Icon'))
            ->add('asociated_option', null, array('label' => 'Asociated option', 'attr' => array('class' => 'select2')));
    }

    /**
     * @param OptionsResolverInterface $resolver
     */
    public function setDefaultOptions(OptionsResolverInterface $resolver)
    {
        $resolver->setDefaults(array(
            'data_class' => 'App\AdminBundle\Entity\Option'
        ));
    }

    /**
     * @return string
     */
    public function getName()
    {
        return 'app_adminbundle_option';
    }
}
