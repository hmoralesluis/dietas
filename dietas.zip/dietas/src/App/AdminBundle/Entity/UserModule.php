<?php

namespace App\AdminBundle\Entity;

use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\ORM\Mapping as ORM;
use Symfony\Component\Validator\Constraints as Assert;

/**
 * Module
 *
 * @ORM\Table(name="user_module_tb")
 * @ORM\Entity(repositoryClass="App\AdminBundle\Entity\UserModuleRepository")
 */
class UserModule
{
    /**
     * @var integer
     *
     * @ORM\Column(name="id", type="integer")
     * @ORM\Id
     * @ORM\GeneratedValue(strategy="AUTO")
     */
    private $id;

    /**
     * @var float
     *
     * @ORM\Column(name="productsLimitPrice", type="float", nullable=true)
     */
    private $productsLimitPrice;

    /**
     * @var integer
     *
     * @ORM\Column(name="cantByProductType", type="integer", nullable=true)
     */
    private $cantByProductType;

    /**
     * @ORM\ManyToOne(targetEntity="User", inversedBy="userModule")
     * @ORM\JoinColumn(name="user_id", referencedColumnName="id", nullable=false)
     */
    private $user;

    /**
     * @ORM\ManyToOne(targetEntity="Module", inversedBy="userModule")
     * @ORM\JoinColumn(name="module_id", referencedColumnName="id", nullable=false)
     */
    private $module;

    /**
     * @var \DateTime
     *
     * @ORM\Column(name="activationDate", type="date")
     */
    private $activationDate;

    /**
     * @ORM\OneToMany(targetEntity="ModuleSale", mappedBy="userModule")
     */
    private $moduleSales;

    /**
     * @inheritdoc
     */
    public function __construct()
    {
        $this->moduleSales = new ArrayCollection();
    }

    /**
     * Get id
     *
     * @return integer
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * Set activationDate
     *
     * @param \DateTime $activationDate
     * @return UserModule
     */
    public function setActivationDate($activationDate)
    {
        $this->activationDate = $activationDate;

        return $this;
    }

    /**
     * Get activationDate
     *
     * @return \DateTime
     */
    public function getActivationDate()
    {
        return $this->activationDate;
    }

    /**
     * Set productsLimitPrice
     *
     * @param float $productsLimitPrice
     * @return UserModule
     */
    public function setProductsLimitPrice($productsLimitPrice)
    {
        $this->productsLimitPrice = $productsLimitPrice;

        return $this;
    }

    /**
     * Get productsLimitPrice
     *
     * @return float
     */
    public function getProductsLimitPrice()
    {
        return $this->productsLimitPrice;
    }

    /**
     * Set cantByProductType
     *
     * @param integer $cantByProductType
     * @return UserModule
     */
    public function setCantByProductType($cantByProductType)
    {
        $this->cantByProductType = $cantByProductType;

        return $this;
    }

    /**
     * Get cantByProductType
     *
     * @return integer
     */
    public function getCantByProductType()
    {
        return $this->cantByProductType;
    }

    /**
     * Set user
     *
     * @param \App\AdminBundle\Entity\User $user
     * @return UserModule
     */
    public function setUser(\App\AdminBundle\Entity\User $user)
    {
        $this->user = $user;

        return $this;
    }

    /**
     * Get user
     *
     * @return \App\AdminBundle\Entity\User
     */
    public function getUser()
    {
        return $this->user;
    }

    /**
     * Set module
     *
     * @param \App\AdminBundle\Entity\Module $module
     * @return UserModule
     */
    public function setModule(\App\AdminBundle\Entity\Module $module)
    {
        $this->module = $module;

        return $this;
    }

    /**
     * Get module
     *
     * @return \App\AdminBundle\Entity\Module
     */
    public function getModule()
    {
        return $this->module;
    }

    /**
     * Add moduleSale
     *
     * @param ModuleSale $moduleSale
     * @return UserModule
     */
    public function addModuleSale(ModuleSale $moduleSale)
    {
        $this->moduleSales[] = $moduleSale;

        return $this;
    }

    /**
     * Remove moduleSale
     *
     * @param ModuleSale $moduleSale
     */
    public function removeModuleSale(ModuleSale $moduleSale)
    {
        $this->moduleSales->removeElement($moduleSale);
    }

    /**
     * Get moduleSales
     *
     * @return \Doctrine\Common\Collections\Collection
     */
    public function getModuleSales()
    {
        return $this->moduleSales;
    }
}
